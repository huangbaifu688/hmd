package com.gupao;

import com.gupaoedu.vip.spring5.demo.RouterConfig;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;

/**
 * Created by Tom.
 */
public class ApplicationContextTest {
    public static void main(String[] args) {

        AnnotationConfigApplicationContext app = new AnnotationConfigApplicationContext(RouterConfig.class);
        Object instance = app.getBean("timerRouter2");
        System.out.println(instance);

    }
}
