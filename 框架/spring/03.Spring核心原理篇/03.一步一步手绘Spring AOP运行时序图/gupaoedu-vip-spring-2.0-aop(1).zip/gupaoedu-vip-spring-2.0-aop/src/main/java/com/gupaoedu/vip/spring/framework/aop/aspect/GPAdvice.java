package com.gupaoedu.vip.spring.framework.aop.aspect;

import lombok.Data;


/**
 * Created by Tom.
 */

public interface GPAdvice {


}
