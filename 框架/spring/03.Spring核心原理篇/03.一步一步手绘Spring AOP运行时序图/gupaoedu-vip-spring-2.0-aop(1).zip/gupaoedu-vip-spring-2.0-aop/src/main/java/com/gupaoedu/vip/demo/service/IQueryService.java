package com.gupaoedu.vip.demo.service;

/**
 * 查询业务
 * @author Tom
 *
 */
public interface IQueryService {
	
	/**
	 * 查询
	 */
	public String query(String name);
}
